#!/bin/bash

# Using prompting (i.e stdin) var assignment
echo "Typing first, then second names"
read firstname
read secondname

# Nombrar las variables con argumentos
primernombre=$1
segundonombre=$2

# Asignacao de variable por valor descrito
namek="Manuel"
namdo="Rosa"

# Assigning variables con entradas de un comando
nameofuser=$(whoami)
fecha=$(date)
diretorio=$(pwd)

# Assigning mathematically edited system+manual variables
getrico=$((($RANDOM%15)+37))

sleep 1

echo "The prompt-based variables are $firstname && $secondname"
sleep 1.5

echo "Las variables nombradas por los argumentos son $primernombre YY $segundonombre"
sleep 1.5

echo "Variaveis fornecidas em codigo sao $nomeum EE $nomedois"
sleep 1

echo "Bash-script ejecutado por $nameofuser, at $fecha atraves de $diretorio"
sleep 1

echo "Getting rich en unos cuantos $getrico años"

