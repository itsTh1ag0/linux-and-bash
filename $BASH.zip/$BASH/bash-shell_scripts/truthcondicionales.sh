#!/bin/bash

valor=$1
read value
valuing="value"
valued=$(command)
valorado=$((expresión))

#else | elif > son opcionales
if [[ $value == true || $valued == "string" && $valorado -lt 100 ]]; then
	echo "do this"
	if [[ !$value  ]]; then
	echo "do this as well"
	fi
elif [[ $valorado -ge (($valued%10))  ]]; then
	exit
	echo "This won't execute por que... ^"
else 
	echo "So do this as default"
fi

# switch-case
case $valor in
	-le $valuing )
	echo "Haz eso aquí ahora"
	;;
	-gt $valueing )
	echo "Do this instead"
	;;
esac

