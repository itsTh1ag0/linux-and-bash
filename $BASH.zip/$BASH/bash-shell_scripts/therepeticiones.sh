#!/bin/bash

# Ejemplo de WHILE
read -p "¿Cuántas veces lo quieres repetir?" repeatN
x=0
while [[ $x -lt $repeatN ]]
do
   read -p "Repetición $x, presiona para seguir"  
  (( x ++ ))
done
echo "Brought hasta aap por $TWITTER"
exit

#Ejemplo con datos de un arquivo
while read -r línea; do
echo "Line $x $línea"
(( x ++ ))
done < arquivo

#Ejemplo de UNTIL
until [[ $variable == true ]]
do
  echo "Eliges el valor del variable"
  read variable
done

#Ejemplos de FOR
for vaso in 1 2 3 4 5 6 7 8 9 10;
for copa in {1..10};
do
  echo "El valor de cups es $vasoOcopa"
done

for x in google.com bing.com meta.com;
do 
  if ping -q -c 2 -W 1 $x > /dev/null; then
  echo "$x is up"
  else
  echo "$x is down"
  fi
done

for x in $(cat ciudades.txt);
do 
  weather=$(curl -s http://wttr.in/$x?format=3)
  echo "El clima en $weather"
done

# Ejemplos de parada y secuencia (BREAK, CONTINUE)
read < arquivo
while algoesverdad
do 
  if comando -o 3 $arquivo > /dev/null; then
    echo "Hay valor en el $arquivo"
    break ## <<
  else
    echo "Sin $arquivo. Sigue el loop"
  fi
sleep 2
done

for x in {1..17};
do
  if [[ $floor == 13  ]]; then
    continue # << means skip
  fi
  echo "Has llegado al piso $x"
  sleep 1
done

