#!/bin/bash

echo "Hey Linux"
sleep 3

echo "Sup bhai.¿Qué pasa pendejo? "
sleep 2

echo "Nothing, solamente de broma"
