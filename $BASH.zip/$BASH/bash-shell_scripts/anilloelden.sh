#!/bin/bash

weapon=$1
cualquieranum=$(( ($RANDOM%10) + 1  ))

echo "Seleccionaste el arma $weapon"
sleep 1.5

echo "¿Le quieres atacar ahora? (s/n)"
read decision

#Else can have empty of arguments
if [[ $decision == "s"  ]]; then
	echo "¡Empecando el combate!"
	if [[ $cualquieranum -ge 5 ]]; then
		echo "Se le daño un $cualquieranum% y murrió"
		exit #Finishes the script
	else
		echo "Dañaste tan solo un $cualquieranum% y sigue vivo"
	fi
else
	echo "Finalizando la lucha!"
fi

echo  "Brought to aap por las manos de $TWITTER"
