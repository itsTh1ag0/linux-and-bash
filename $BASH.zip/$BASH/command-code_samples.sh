## BASH/SHELL Commands/Snippets ##

which $SHELL|BASH # Identifies mounted fs location
-
echo "<anything>" # Writes to sdt-out terminal (i.e SHELL)
-
#!/bin/bash # Shebang statement, states a BASH script
-
bash <shellscript-file> # Executes files containing bash code
-
sleep [NUM] # Timeouts in seconds
-
./<file>.sh # Directly executes files (within current/selected folder)
-
chmod +|-[x|r|w] # Changes user/grp/others file privilegies
-
varname="value" # Variable declaration syntax
-
read varname # Reads stdin during bash-runtime and saves-evokes within variables
-
varname=$[NUM] ... bash scriptname <args> # Asign variable<>value based on argument evoking script
# A.K.A Positional argument | Positional paramenter
-
varname=$(cmd) # Utilizing shell commands within script variables
-
$RANDOM # SHELL variable, stores int NUM between 0<>32767 *(short for ramdomly)
#TWITTER="X-Musk" -> How to declare SHELL variables (non-caps_needed)
-
export <SHELL-VAR> # Commits and add manually added/modded variables to system-base-db
-
exit # Leaves current shell connection (i.e closes terminal)
-
nano ~/.bashrc ... (at end-of_file) export VARNAME=<value> # Adds permantly committed SHELL variables
-
echo $(( 2 * 3 / 2 + 1 - 4 )) # Mathematic/Arithmeric expressions within SHELL 
# Doesn't return decimals (float) by default it "rounds"
-
if [[ <conditions> ]]; then \... # Conditional base-structure
	if [[ <conditions> ]]; then \...
	fi
elif [[ <conditions> ]]; then \... 
else \... 
fi
-
exit # Finishes a script prematurely
-
case value in # Switch-casing
	pattern )
	...
	;;
	otherpattern )
	...
	;;
esac
--
-gt/> | -ge/>= | -lt\< | -le\<= # Comparison operators for variables
--
read -p "Promt-text" varname # Reads/Stores input with 'Promting'
#varname can be omitted
--
while  [[ value -le $variable ]] do ... done # Ways of while-looping
while cmd -o value; do ... done < filesource
while true do ... done
--
{1..10} # NUM range notation
--
for x in value1 value2 | comand -o < file | {1..100} ; do ... done # For looping variants
--
break & continue # Stopping or Skipping a loop prematurely
--
